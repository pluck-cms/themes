<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Curiously Green
Version    : 1.0
Released   : 20080425

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911

-->
<html>
<head>
<?php theme_meta(); ?>
</head>
<body>

<div id="header">
	<div id="header_inner">
		<h1><?php theme_sitetitle(); ?></h1>
		<div id="slogan">Ported to Pluck by Tadziz.</div>
	</div>
</div>

<div id="main">

	<div id="lcol">
		<div id="menu">
			<?php theme_menu('ul', 'li', 'active', 0); ?>
		</div>
		<div id="menu_end"></div>

		<div id="lcontent">
		<a href="login.php">Login</a>
		</div>

	</div>
	
	

	<div id="rcol">
		<div id="rcontent">
		
			<h1><span><?php theme_pagetitle(); ?></span></h1>
			<div class="box">
				<div class="box_inner">	
					<?php theme_content(); ?>							
				</div>
			</div>
			<div class="divider"></div>
				
			

		</div>
	</div>

</div>

<div id="footer">
	© 2009 edited by Tadziz | Design by <a href="http://www.nodethirtythree.com/">ntt</a> + <a href="http://www.freecsstemplates.org/">fct</a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
</div>

</body>
</html>