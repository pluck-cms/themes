<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
<?php theme_meta(); ?>
  </head>
  <body>
  	<div id="wrapper">
  		<div id="leftColumn">
        <div id="navContainer">
		<ul>
		<?php theme_menu('<li><a href="#file">#title</a></li>','<li class="active"><a href="#file">#title</a></li>'); ?> 
		</ul>
        </div>
        <div id="eventContainer">
        	<?php theme_module("sidebar"); ?>
        </div>
        </div>
        
        <div id="rightColumn">
         <div id="aboutContainer">
		 <img src="data/themes/fatcats/images/main.jpg" alt="" border=0" />
		 	<h2><a href="#"><?php theme_pagetitle(); ?></a></h2>
			<p><?php theme_content(); ?></p>
			<p><?php theme_module("main"); ?></p>
         </div>
        </div>
  
  		<div style="height:0px;line-height:0px;clear:both;">&nbsp;</div>
        <div id="foot"><a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></div>
  	</div>
  </body>
  </html>
  

