<?php
//This is the converted to pluck theme: "Zenlike"
//Design by: nodethirtythree design: http://www.nodethirtythree.com
//Theme Converted by: J G Metcalfe http://www.t4p.me.uk
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "zenlike";
$themename = "Zenlike";
$module_space[0] = "main";
$module_space[1] = "footer";
?>