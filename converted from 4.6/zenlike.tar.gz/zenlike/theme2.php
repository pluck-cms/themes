<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>

<body>

<div id="upbg"></div>

<div id="outer">
  <div id="header">
    <div id="headercontent">
      <h1><?php theme_sitetitle(); ?></h1>
    </div>
  </div>

  <div id="headerpic"></div>

  <div id="menu">
    <ul>
      <?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file"  class="active">#title</a></li>'); ?>
    </ul>
  </div>

  <div id="menubottom"></div>

  <div id="content">
    <div id="normalcontent">
      <h3><span><?php theme_pagetitle(); ?></span></h3>

      <div class="contentarea">
        <p>
        <?php theme_content(); ?>
        <?php theme_module("main"); ?>
        </p>
      </div>
    </div>

  </div>

  <div id="footer">
    <?php theme_module("footer"); ?>
    <div class="left">
	&copy; 2010 All rights reserved | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></div>
    <div class="right">Design by <a href="http://www.nodethirtythree.com/">ntt</a> + <a href="http://www.freecsstemplates.org/">fct</a></div>
  </div>
</div>		
</body>
</html>