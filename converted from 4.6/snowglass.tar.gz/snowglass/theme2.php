<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

Design by NodeThirtyThree <http://www.nodethirtythree.com>
Published by Free CSS Templates <http://www.freecsstemplates.org/>
Released for free under a Creative Commons Attribution 2.5 License

Title      : snowglass
Version    : 1.0
Released   : 20070718
Description: A two-column, fixed-width template featuring a blue glass effect ideal for 1024x768 resolutions.

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="header">
	<div id="logo">
		<h1>SnowGlass</a></h1>
		<h2>theme for pluck</h2>
		</div>
	<div id="menu">
		<ul>
		
		</ul>
	</div>
</div>
<hr />
<div id="page">
	<div id="bg">
		<div id="content">
			<div class="post" style="padding-top: 57px;">
				<h2 class="title"><?php theme_pagetitle(); ?></h2>
								<div class="entry">
								<?php theme_module("main"); ?>
					
								<?php theme_content(); ?>
				</div>
				
			</div>
			<div class="post">
				
			</div>
			
		</div>
		<!-- end contentn -->
		<div id="sidebar">
		<h2 style="font-size:20px">Search</h2>
		<?php theme_module("search"); ?>
        <?php theme_module("sidebar"); ?>
			<ul>
				<li>
					<h2>Menu</h2>
					<ul>
						<?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>
					</ul>
				</li>
				</li>
			</ul>
		</div>
		<!-- end sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
</div>
<!-- end page -->
<hr />
<div id="footer">
<?php theme_module("footer"); ?>
	<p>(c) 2009 Design by <a href="http://www.nodethirtythree.com/">ntt</a> + <a href="http://www.freecsstemplates.org/">fct</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
</body>
</html>
