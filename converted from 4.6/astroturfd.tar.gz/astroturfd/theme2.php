<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

Design by NodeThirtyThree for Free CSS Templates
http://www.nodethirtythree.com + http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : astroturfd
Description: A three-color, two-column, fixed-width design.
Version    : 1.0
Released   : 20081120

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="wrapper">
	<div id="bg1">
		<div id="bg2">
			<div id="header">
				<div id="logo">
					<h1 style="display:inline"><a href="#"><?php theme_sitetitle(); ?></a></h1>
				</div>
				<!-- end #logo -->
				<div id="menu">
					<ul>
					<?php theme_menu('<li><a href="#file">#title</a></li>','<li class="first current_page_item"><a href="#file">#title</a></li>'); ?>
					</ul>
				</div>
				<!-- end #menu -->
			</div>
			<!-- end #header -->
			<div id="page">
				<div id="content">
					<div class="post">
						<h2 class="title"><?php theme_pagetitle(); ?></h2>
						<div class="entry">
							<?php theme_content(); ?>
            <?php theme_module("main"); ?>
						</div>
					</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<div class="post">
						<div class="entry">
                            <?php theme_module("sidebar"); ?>
							<h2>Search</h2>
							<?php theme_module("search"); ?>
							<h2>Submenu</h2>
							<ul class="list2">
								<?php theme_submenu('<li><a href="#file" title="#title">#title</a></li>'); ?>
							</ul>
						</div>
					</div>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
				<div id="footer">
					<?php theme_module("footer"); ?>
		  <p>(c) 2009. Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a> and <a href="http://www.freecsstemplates.org/">Free CSS Templates</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
	</div></p>
				</div>
				<!-- end #footer -->
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<!-- end #wrapper -->
</body>
</html>
