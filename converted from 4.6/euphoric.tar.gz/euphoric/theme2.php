<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Theme name: Euphoric
Theme Made by: http://www.tristarwebdesign.co.uk
This is a pluck theme-file
You can find pluck at http://www.pluck-cms.org

Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
-->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
</head>
<body>
<div id="headercontainer"><div id="header">
<h1><?php echo $site_title; ?></h1>
</div>
</div>
<div id="menucontainer">
<div id="menu">
<div id="navcontainer">
<ul id="navlist">
      	 <?php theme_menu('<li><a href="#file" title="#title">#title</a></li>','<li><a href="#file" class="active" title="#title">#title</a></li>'); ?>
</ul></div></div></div>

<div id="content"><h2 title="<?php theme_pagetitle(); ?>"><?php theme_pagetitle(); ?></h2>
<?php theme_content(); ?>
<?php theme_module("main"); ?>		
</div> 

<div id="footer">
design by <a href="http://www.tristarwebdesign.co.uk">tri-star webdesign</a> || 
ported by <a title="Pozycjoniwanie i tworzenie stron internetowych EKYO" href="http://www.ekyo.pl">eKyo</a> || <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> || << <a href="login.php">admin</a>
</div>  
</body> 
</html>