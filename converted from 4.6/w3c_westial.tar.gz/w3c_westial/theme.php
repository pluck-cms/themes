<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es">
<head>
<?php theme_meta(); ?>
</head>

<body>

<?php //here you obtain the name of part without extension:
$extension = pathinfo($_GET['file'], PATHINFO_EXTENSION);
$nombre_base = basename($_GET['file'], '.'.$extension);
if ($_GET['file']==""){
	$extension = pathinfo($_GET['file2'], PATHINFO_EXTENSION);
	$nombre_base = basename($_GET['file2'], '.'.$extension);
	$_GET['file']= $_GET['file2'];
}   
?>

<div id="titol"><?php theme_sitetitle();?></div>
<table cellpadding="10" title="contenidos principales de la web" width="80%" cellspacing="10" style="margin-left:20px" summary="division de la pantalla en menu a la izquierda y contenidos a la derecha">
	<tr valign="top">
    <td title="Barra de botones" style="width: 20%">
			<?php theme_menu('span', 'p class="menubtn"', 'active', 0); ?>
     </td>
    <td>
     <div id="general">
        <h1><?php theme_pagetitle(); ?></h1><br />
        <div id="contenido">                    
			<?php 
			theme_content();
			?>
    
    
        </div>
    </div>
    </td>
    </tr>
</table>

<div class="piepagina"> - 

<a href="http://pluck-cms.org"><img src="data/themes/w3c_westial/img/pluck.jpg" alt="pluck-cms.org"/></a> - 
<a href="http://westial.com"><img src="data/themes/w3c_westial/img/logowestialbtn.jpg" alt="westial.com" width="80" height="27"/></a>
<?php
	//here you must discriminate the parts of web doesn't let triple A accessibility:
	if (($nombre_base!="kop2")&&($nombre_base!="kop3")&&($nombre_base!="kop4")){//&&($nombre_base!="part of web unaccessible")
		?>
        <!-- VERY IMPORTANT: TEST THE LINKS TO W3C VALIDATORS AND TEST THE TRIPLE A ACCESSIBILITY BEFORE MAKE PUBLIC THE WEBSITE, AND DON'T PRINT THE W3C LABELS IF THE WEBSITE HAVE ANY ERROR -->
		<a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="CSS Valido"/>		</a>
		 - 
		<a href="http://validator.w3.org/check?uri=referer"><img
				src="http://www.w3.org/Icons/valid-xhtml10"
				alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a>
                 - 
        <a href="http://www.w3.org/WAI/WCAG1AAA-Conformance"
        title="Explicacion del Nivel Triple-A de 
        Conformidad">
    <img height="32" width="88" 
        src="http://www.w3.org/WAI/wcag1AAA"
        alt="Icono de conformidad con el Nivel Triple-A, 
        de las Directrices de Accesibilidad para el 
        Contenido Web 1.0 del W3C-WAI"/></a>

<?php }
?>
</div>



</body>
</html>