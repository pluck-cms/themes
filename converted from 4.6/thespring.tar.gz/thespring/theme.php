<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="header">
	<h1><?php theme_sitetitle(); ?></h1>
</div>
<div id="content">
	<div id="colOne">
		<div class="post">
			<h2 class="title"><?php theme_pagetitle(); ?></h2>
			<div class="story">
				</div>
			<div class="meta">
		
			
			</div>
		</div>
		<div class="post">
				<?php theme_content(); ?>
		</div>
	</div>
	<div id="colTwo">
		<ul>
			<li>
			</li>
			
		</ul>
	</div>
	<div style="clear: both;"> </div>
</div>
<div id="menu">
			<?php theme_menu('ul', 'li', 'active', 0); ?>
</div>
<div id="footer">
	<p>Copyright © 2009 The Spring. Designed by <a href="http://www.freecsstemplates.org">fct</a> | Powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
</body>
</html>
