<?php
//This is pluck theme: "Gemini"
//Author: Jinsona designs URI: http://web2feel.com/
//Theme converted by: J Metcalfe http://www.t4p.me.uk
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "gemini";
$themename = "Gemini";
$module_space[0] = "main";
$module_space[1] = "footer";
$module_space[2] = "sidebar";
?>