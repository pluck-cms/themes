<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911

-->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
<link rel="stylesheet" type="text/css" href="data/themes/gemini/dark.css" media="screen" title="dark">
<link rel="alternate stylesheet" type="text/css" href="data/themes/gemini/light.css" media="screen" title="light">
<script type="text/javascript">
function setActiveStyleSheet(title) {
    var i, a, main;
    for (i = 0; (a = document.getElementsByTagName("link")[i]); i++) {
        if (a.getAttribute("rel").indexOf("style") != - 1 && a.getAttribute("title")) {
            a.disabled = true;
            if (a.getAttribute("title") == title) 
                a.disabled = false;
        }
    }
}
function getActiveStyleSheet() {
    var i, a;
    for (i = 0; (a = document.getElementsByTagName("link")[i]); i++) {
        if (a.getAttribute("rel").indexOf("style") != - 1 && a.getAttribute("title") && !a.disabled) 
            return a.getAttribute("title");
    }
    return null;
}
function getPreferredStyleSheet() {
    var i, a;
    for (i = 0; (a = document.getElementsByTagName("link")[i]); i++) {
        if (a.getAttribute("rel").indexOf("style") != - 1 && a.getAttribute("rel").indexOf("alt") == - 1 && a.getAttribute("title") ) 
            return a.getAttribute("title");
    }
    return null;
}
function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    } else 
        expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') 
            c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) 
            return c.substring(nameEQ.length, c.length);
    }
    return null;
}
window.onload = function(e) {
    var cookie = readCookie("style");
    var title = cookie ? cookie : getPreferredStyleSheet();
    setActiveStyleSheet(title);
}
window.onunload = function(e) {
    var title = getActiveStyleSheet();
    createCookie("style", title, 365);
}
var cookie = readCookie("style");
var title = cookie ? cookie : getPreferredStyleSheet();
setActiveStyleSheet(title);


</script>

</head>

<body>

<div class="wrapper">
  <div class="top">
    <div class="blogname">
      <h1><a href="#"><?php theme_sitetitle(); ?></a></h1>
      <h2>Site Description or Slogan</h2>
    </div>
  </div>

  <div id="foxmenucontainer">
    <div id="foxmenu">
		<?php theme_menu('ul', 'li', 'active', 0); ?>
    </div>
  </div>

  <div class="content">
    <div id="content"><a name="content"></a>
      <div class="post" id="post-12">
        <div class="title"><h2><?php theme_pagetitle(); ?></h2>
          <div class="cover">
		    <div class="entry">
		    <p>
		      <?php theme_content(); ?>
		    </p>
            </div>
          </div>
        </div></div>
	    <!-- div class="navigation">
		  <div class="alignleft">left</div>
		  <div class="alignright">right</div>
		</div-->
     </div>
<div class="rightcolumn">
  <div id="styleswitcher">
  <a href="#" onclick="setActiveStyleSheet('dark'); return false;"><img src="data/themes/gemini/images/dark.jpg" alt="Switch to Dark fonts"></a>
<a href="#" onclick="setActiveStyleSheet('light'); return false;"><img src="data/themes/gemini/images/light.jpg" alt="Switch to Light fonts"></a>
</div>
<div class="sidebar">
  <ul>
    <li>
		<h2 style="font-size:20px">Submenu</h2>
			<?php theme_menu('ul', 'li', '', 1); ?>
	</li>
  </ul>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div id="footer">
    Copyright (c) 2008 Sitename.com. All rights reserved. | Author: <a href="http://web2feel.com/">Jinsona designs</a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
  </div>
</div>		
</body>
</html>