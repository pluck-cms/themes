<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Title      : Connection
Version    : 1.1
Released   : 20070408
Description: A very customizable fixed-width template suitable for blogs and small business websites. Colors can be changed in the CSS.
Ported to Pluck 4.6.x by A_Bach

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="page">
	<div id="logo">
		<h1><a href="#" title="<?php echo $site_title ?>"><?php echo $site_title ?></a></h1>
	</div>
	<div id="menu">
		<ul>
      	 <?php theme_menu('<li><a href="#file" title="#title">#title</a></li>','<li><a href="#file" class="active" title="#title">#title</a></li>'); ?>
      </ul>
	</div>
	<div id="content">
		<div id="main">
			<div id="welcome" class="post">
<h2 title="<?php theme_pagetitle(); ?>"><?php theme_pagetitle(); ?></h2>
<?php theme_content(); ?>
<?php theme_module("main"); ?>		
			</div>
		</div>
	</div>
	<div id="footer">
   <p id="legal"><?php theme_module("footer"); ?>
      <!-- Please leave these credit links intact as they are small and unobtrusive to the theme. Thanks! -->
      Designed by <a href="http://www.freecsstemplates.org/">fct</a>. Ported by <a href="http://www.ekyo.pl" title="EKYO">eKyo</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
      </p>
	</div>
</div>
</body>
</html>
