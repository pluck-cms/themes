<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Ofir
http://www.facethemap.com
Released for free under a Creative Commons Attribution 2.5 License

Title      : pastel
Version    : 1
Description: A very customizable fixed-width template suitable for personal and small business websites. Colors can be changed in the CSS.
Ported to Pluck 4.6.x by A_Bach

//Modified for Pluck 4.7.x by BSteelooper
Version    : 2.0
Released   : 20140911
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>

<body>
<div id="logo">
		<h1><a href="#" title="<?php echo $site_title ?>"><?php echo $site_title ?></a></h1>
	</div>
<br> <br><br>

<div id="page">
	
	<div id="menu">
			<?php theme_menu('ul', 'li', 'active', 0); ?>
	</div>
	<div id="content">
		<div id="main">
			<div id="welcome" class="post">
<h2 title="<?php theme_pagetitle(); ?>"><?php theme_pagetitle(); ?></h2>
<?php theme_content(); ?>
			</div>
		</div>
	</div>
	<div id="footer">
   <p id="legal">
    Design by <a href="http://facethemap.com">Ofir</a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
	</p>
</div>
</div>
</body>
</html>