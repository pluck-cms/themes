<?php
//This is the theme "Green", included with pluck
//Theme Made by: Dennis, http://www.rs11.nl
//You can find pluck at http://www.pluck-cms.org

$themedir = "green";
$themename = "Green";
$module_space[1] = "footer";
?>