<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Released   : 20100110

//Modified for Pluck 4.7.x by BSteelooper
Version    : 2.0
Released   : 20140911

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
	<!--[if lte IE 6]>
	<link rel="stylesheet" type="text/css" href="ie6.css" media="screen" />
	<![endif]-->
</head>
<body>

<div id="header" class="title">
			<h1><a href="#"><?php echo $site_title ?></a></h1>
			<h4><?php theme_pagetitle(); ?></h4>
</div>
<div id="wrapper">
<div id="container">
		<div class="post">
			<h2><?php theme_pagetitle(); ?></h2>
			<div class="entry">
<?php theme_content(); ?>
			</div>
		</div>

		<div class="navigation">
					</div>
</div>
<!-- Start Sidebar -->
<div class="sidebar">
	<ul>
	<li><h2>Navigation</h2>
			<?php theme_menu('ul', 'li', 'active', 0); ?>
	</li>
	<li><h2>Meta</h2>
		<ul>
			<li><a href="login.php">Login</a></li>
		</ul>
	</li>
</ul>
</div>

<!-- End Sidebar -->
<div id="footer">
<p>CC-BY-SA 3.0 Darkwater Theme for Wordpress by <a href="http://antbag.com/">Antbag</a> | Ported by <a href="http://www.ekyo.pl/" target="_blank" title="Pozycjonowanie stron www rzeszów">eKyo</a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
</div>
</body>
</html>