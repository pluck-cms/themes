<?php
//This is the theme by Kykoo adapted for Pluck by superdad: "red_flower"
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "red_flowers";
$themename = "Red flowers";
$module_space[0] = "main";
$module_space[1] = "footer";
?>