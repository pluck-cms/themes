<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Abrasive
Description: A two-column, fixed-width design with dirty looks.
Version    : 1.0
Released   : 20081122

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110


-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#"><?php theme_sitetitle(); ?></a></h1>
		</div>
		<!-- end #logo -->
        <span id="menu">
            <ul>
                <?php theme_menu('<li><a href="#file">#title</a></li>','<li class="first"><a href="#file">#title</a></li>'); ?> 
            </ul>
        </span>
        <!-- end #menu -->
	</div>
	<!-- end #header -->
	<div id="page">
		<div id="bgtop">
			<div id="bgbottom">
				<div id="content">
					<div class="post">
						<div class="title">
							<h2><a href="#"><?php theme_pagetitle(); ?></a></h2>
							<p>&nbsp;
                            </p>
						</div>
						<div class="entry">                        
					  <?php theme_content(); ?>
                      <?php theme_module("main"); ?>
                        </div>
					</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">                
                <div id="fecha">
                <SCRIPT LANGUAGE="JavaScript1.2">
                    <!-- Begin
                    var months=new Array(13);
                    months[1]="January";
                    months[2]="February";
                    months[3]="March";
                    months[4]="April";
                    months[5]="May";
                    months[6]="June";
                    months[7]="July";
                    months[8]="August";
                    months[9]="September";
                    months[10]="October";
                    months[11]="November";
                    months[12]="December";
                    var time=new Date();
                    var lmonth=months[time.getMonth() + 1];
                    var date=time.getDate();
                    var year=time.getYear();
                    if (year < 2000)    
                    year = year + 1900;
                    document.write("<center>" + date + " - " + lmonth + " - " + year + "</center>");	
                    // End -->
                </SCRIPT>	
                </div>
					<ul>
						<li>
							<h2 style="font-size:20px">Search</h2>
							<?php theme_module("search"); ?>
							<h2 style="font-size:20px">Submenu</h2>
                            <?php theme_module("sidebar"); ?>
							<ul>
							<?php theme_submenu('<li><a href="#file" title="#title">#title</a></li>'); ?>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
	<div id="footer">
  <?php theme_module("footer"); ?>
  <p>Copyright (c) 2009. Design by <a href="http://www.nodethirtythree.com/">ntt</a> and <a href="http://www.freecsstemplates.org/">fct</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
	</div>
	<!-- end #footer -->
</div>
<!-- end #wrapper -->
</body>
</html>
