<?php
//This is the theme "curiouslygreen"
//You can find pluck at http://www.pluck-cms.org
//Theme made by http://www.freecsstemplates.org, designed for bluck by Tadziz
//Tadziz site themes for pluck http://pluckthemes.xz.lt

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "abrasive";
$themename = "Abrasive";
$module_space[0] = "main";
$module_space[1] = "footer";
$module_space[2] = "search";
?>