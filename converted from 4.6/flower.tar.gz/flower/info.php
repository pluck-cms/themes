<?php
//This is the old default theme of pluck
//designed by soloinc.com based on a desidn from
//Sander Thijsen, http://www.somp.nl
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "flower";
$themename = "Flower";
$module_space[0] = "main";
$module_space[1] = "footer";
?>