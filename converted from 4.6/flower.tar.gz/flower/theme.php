<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Released   : 20100110

Modified for Pluck 4.7.x by BSteelooper
Version    : 2.0
Released   : 20140911


-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>

<body>
<div class="head">
	<div class="header">
		<div class="headerkop"><?php theme_sitetitle(); ?></div>
		<div class="menu">
			<?php theme_menu('span','span style="padding-left:5px;padding-right:5px;border-right:solid 2px;"','',0); ?>
		</div>
	</div>

	<div class="content">
		<div class="kop"><?php theme_pagetitle(); ?></div><br />
		<div class="txt">
			<?php theme_content(); ?>
			<div class="footer">
				  designed by <a href="http://www.soloinc.com">Solo Services </a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
			</div>
		</div>
	</div>
</div>
</body>
</html>