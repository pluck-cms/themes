<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<?php theme_meta(); ?>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="header">
  <h1><a href="index.php"><?php theme_sitetitle(); ?></a> </h1>
</div>
<div id="content">
  <div id="colOne">
    <h2>Menu</h2>
			<?php theme_menu('ul', 'li', 'active', 0); ?>
  </div>
  <div id="colTwo">
    <h1><?php theme_pagetitle(); ?></h1>
   <?php theme_content(); ?>
  </div>
  
  <div style="clear: both;"> </div>
</div>
<div id="footer">
  <p>Copyright © 2006 Pomodoro. Designed by <a href="http://freecsstemplates.org"><strong>fct</strong></a> | powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
</body>
</html>
