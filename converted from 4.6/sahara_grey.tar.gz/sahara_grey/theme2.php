<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<?php theme_meta(); ?>
</head>
<body>

<div id="outer">
	<div id="outer2">

		<div id="header">
			<h1><?php theme_sitetitle(); ?></h1>

		</div>

		<div id="menu">

                        <?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>

		</div>

		<div id="content">

			<div id="column1">
				<h3><?php theme_pagetitle(); ?></h3>
                               	<?php theme_content(); ?>
                                 <?php theme_module("main"); ?>

			</div>

		</div>

		<div id="footer">
		<?php theme_module("footer"); ?>
			<p>Copyright &copy; 2010 Design by <a href="http://www.freecsstemplates.org/">fct</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
                 </div>
	</div>
</div>
</body>
</html>