<?php
//This theme is based on the theme "Sahara"
//Theme Made by: http://www.freecsstemplates.org
//You can find pluck at http://www.pluck-cms.org
//ported to Pluck 4.6 by Elron, graphics by Gilrael

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "sahara_grey";
$themename = "Sahara grey";
$module_space[0] = "footer";
$module_space[1] = "main";
?>