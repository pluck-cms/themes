<?php
//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "reckoning";
$themename = "Reckoning";
$module_space[0] = "main";
$module_space[1] = "search";
?>