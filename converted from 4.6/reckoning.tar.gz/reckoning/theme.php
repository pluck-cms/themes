<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Reckoning
Description: A two-column, fixed-width design for 1024x768 screen resolutions.
Version    : 1.0
Released   : 20090629

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<div id="wrapper">

	<div id="header">
		<div id="menu">
		<?php theme_menu('ul', 'li', 'active', 0); ?>
		</div>
		<!-- end #menu -->
	</div>
	<!-- end #header -->
	<div id="logo">
		<h1><a href="#"><?php theme_sitetitle(); ?></a></h1>
	</div>
	<hr />
	<!-- end #logo -->
<!-- end #header-wrapper -->

<div id="page">
		<div class="post">
			<h2 class="title"><?php theme_pagetitle(); ?></h2>
			<div class="entry">
				<?php theme_content(); ?>
			</div>
		</div>
	</div>
	<!-- end #content -->
	<div style="clear: both;"> </div>
</div>
<!-- end #page -->

<div id="footer">
	<p>Copyright (c) 2009 Design by <a href="http://www.freecsstemplates.org/">fct</a> | Powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
<!-- end #footer -->
</div>
</body>
</html>
