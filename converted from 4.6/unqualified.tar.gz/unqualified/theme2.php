<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Unqualified
Description: A two-column, fixed-width design.
Version    : 1.0
Released   : 20071220

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="#">unqualified</a></h1>
	</div>
	<div id="menu">
		<ul>
		<li class="active"><?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>
		</ul>
	</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title"><?php theme_pagetitle(); ?></h1>
			<?php theme_content(); ?>
			<p class="byline">
			<div class="entry">
			<?php theme_module("main"); ?>
				
			</div>
			<p class="meta">
		</div>
		
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li>
				<h2>Menu</h2>
				<ul>
				<?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>
					
				</ul>
				<?php theme_module("sidebar"); ?>
			</li>
					</ul>
	</div>
	<!-- end sidebar -->
</div>
<!-- end page -->
<div id="footer">
<?php theme_module("footer"); ?>
	<p>&copy;2009 Design by <a href="http://www.freecsstemplates.org/">fct</a> &nbsp;&bull;&nbsp; Ported to pluck by tadziz | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a></p>
</div>
</body>
</html>
