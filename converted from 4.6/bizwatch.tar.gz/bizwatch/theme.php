<?/*
//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911
*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
</head>

<body>
<div id="calosc">
	<div id="baner">
		<a href="#"><img id="logo" src="data/themes/bizwatch/images/img03.jpg" /></a>
	</div> <!-- baner -->
	
<div id="content">
	<div id="sidebar">
		<div id="menu">
			<?php theme_menu('ul', 'li', 'active', 0); ?>
		</div>
	</div> <!-- sidebar, menu -->
	
	<div id="main">
	<div id="welcome" class="post">

<h2><?php theme_pagetitle(); ?></h2>
	<div class="story">
<?php theme_content(); ?>
	</div> <!-- story -->
	</div> <!-- welcome -->
	</div> <!-- main -->
</div>  <!-- content -->
<div id="footer">
<a href="login.php">admin</a>
				<br />powered by <a href="http://www.pluck-cms.org">pluck</a>
</div> <!-- footer -->
</div> <!-- calosc -->

</body>
</html>