<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
</head>

<body>
<div id="calosc">
	<div id="baner">
		<a href="#"><img id="logo" src="data/themes/<?php echo $site_theme; ?>/images/img03.jpg" /></a>
	</div> <!-- baner -->
	
<div id="content">
	<div id="sidebar">
		<div id="menu">
		<ul>
			<?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>
		</ul>
	</div>
	<div id="search">
	<h2 style="font-size:20px">Search</h2>
	<?php theme_module("search"); ?>
	</div>
	</div> <!-- sidebar, menu -->
	
	<div id="main">
	<div id="welcome" class="post">

<h2><?php theme_pagetitle(); ?></h2>
	<div class="story">
<?php theme_content(); ?>
<?php theme_module("main"); ?>
	</div> <!-- story -->
	</div> <!-- welcome -->
	</div> <!-- main -->
</div>  <!-- content -->
<div id="footer">
				<?php theme_module("footer"); ?>
				Modified by <a href="http://www.ekyo.pl/" target="_blank">EKYO</a> >> <a href="login.php">admin</a>
				<br />powered by <a href="http://www.pluck-cms.org">pluck</a>
</div> <!-- footer -->
</div> <!-- calosc -->

</body>
</html>
