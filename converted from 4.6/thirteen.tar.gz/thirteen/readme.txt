Theme Name: Thirteen
Theme URI: http://beccary.com/goodies/wordpress-themes/
Description: A stylish theme in green. Two columns, fixed width. 
Version: 1.2
Author: Becca Wei
Author URI: http://beccary.com

Ported to CPG by: Billy Bullock
Porter URL: http://www.billygbullock.com
CPG Version: 1.0

Ported from CPG into Pluck: A_Bach
Porter URL: http://www.ekyo.pl
Pluck Version: 1.0

License -
The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php

This program is free software; you can redistribute it and/or modify it under 

The terms of the GNU General Public License as published by the Free Software 
Foundation, version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 

PARTICULAR PURPOSE. See the GNU General Public License for more details.