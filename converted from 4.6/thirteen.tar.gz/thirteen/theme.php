<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
</head>
<body>
<!-- Start Header -->
<div id="headwrapper">
	<div id="header">
		<h1 id="title"><a href="index.php"><?php echo theme_sitetitle(); ?></a></h1>
	</div>
</div>
<!-- End Header -->

<!-- Start main content -->
<div id="wrapper">

<div id="content">
<h2><?php theme_pagetitle(); ?></h2>
<?php theme_content(); ?>
</div>
<!-- End main content -->

<!-- Start Sidebar -->
   <div id="sidebar">
	<?php theme_menu('ul', 'li', 'active', 0); ?>
   </div>
<!-- End Sidebar -->

<!-- Start Footer -->
   <div id="footer"><p style="allign:center;">
      <!-- Please leave these credit links intact as they are small and unobtrusive to the theme. Thanks! -->
     Theme Design : "Thirteen" by <a href="http://www.beccary.com" title="Beccary">Beccary</a> Ported to Pluck by <a href="http://www.ekyo.pl" title="EKYO">eKyo</a> | Powered by <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
      </p>
   </div>
<!-- End Footer -->

</div> <!-- End Wrapper -->
</body>
</html>	

