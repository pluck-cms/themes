<?php
//This is the theme "thirteen"
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/

$themedir = "thirteen";
$themename = "Thirteen";
$module_space[0] = "main";
$module_space[1] = "sidebar";
?>