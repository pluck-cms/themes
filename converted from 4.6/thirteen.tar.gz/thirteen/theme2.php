<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Modified for Super Pluck 4.6.3 Power Pack by A_Bach
A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php theme_meta(); ?>
</head>
<body>
<!-- Start Header -->
<div id="headwrapper">
	<div id="header">
		<h1 id="title"><a href="index.php"><?php echo $site_name; ?></a></h1>
	</div>
</div>
<!-- End Header -->

<!-- Start main content -->
<div id="wrapper">

<div id="content">
<h2><?php theme_pagetitle(); ?></h2>
<?php theme_content(); ?>
<?php theme_module("main"); ?>		

</div>
<!-- End main content -->

<!-- Start Sidebar -->
   <div id="sidebar">
      <ul>
      	 <?php theme_menu('<li><a href="#file">#title</a></li>','<li><a href="#file" class="active">#title</a></li>'); ?>
      </ul>
   </div>
<!-- End Sidebar -->

<!-- Start Footer -->
   <div id="footer">
   <p><?php theme_module("footer"); ?>
      <!-- Please leave these credit links intact as they are small and unobtrusive to the theme. Thanks! -->
      WP Theme Design : "Thirteen" by <a href="http://www.beccary.com" title="Beccary">Beccary</a> Ported to CPG by <a href="http://www.billygbullock.com" title="Billy G Bullock">Billy Bullock</a> Ported to Pluck by <a href="http://www.ekyo.pl" title="EKYO">eKyo</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | << <a href="login.php">admin</a>
      </p>
   </div>
<!-- End Footer -->

</div> <!-- End Wrapper -->
</body>
</html>	


