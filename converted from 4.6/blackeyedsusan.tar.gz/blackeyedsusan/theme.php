<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Black Eyed Susan 
Description: A two-column, fixed-width design.
Version    : 1.0
Released   : 20081109

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/
Version    : 2.0
Released   : 20100110

//Modified for Pluck 4.7.x by BSteelooper
Version    : 3.0
Released   : 20140911

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>
<body>
<!-- start header -->
<div id="header">
	<h1><strong><?php theme_sitetitle(); ?></strong> </h1>
	<p> <?php echo "$Slogan"; ?></p>
</div>
<!-- end header -->
<!-- start page -->
<div id="wrapper">
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title"><?php theme_pagetitle(); ?></h1>
			<div class="entry">
				<?php theme_content(); ?>
            </div>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li>
 			<?php theme_menu('ul', 'li', 'active', 1); ?>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
</div>
	<div style="clear:both"> </div>
</div>
<!-- end page -->
<div id="footer">
	<p> © 2007 All Rights Reserved  •  Design by   <a href="http://www.freecsstemplates.org/">Free CSS Templates</a> powered by: <a href="http://www.pluck-cms.org/">pluck</a> <a href="login.php">admin</a></p>
</div>
</body>
</html>
