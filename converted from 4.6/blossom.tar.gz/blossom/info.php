<?php
//This theme, called "Blossom" is based on "Coffee" by J G Metcalfe.
// It was created by Bert Vercauteren: http://verbertus.co.cc
// What follows is John Metcalfe's info:
//This is the converted to pluck theme: "Coffee"
//Design by Colombia Hosting: http://www.colombiahosting.com.co
//Theme Converted by: J G Metcalfe http://www.t4p.me.uk
//You can find pluck at http://www.pluck-cms.org

//Modified for Super Pluck 4.6.3 Power Pack by A_Bach
//A_Bach eKyo site for pluck http://www.pluck.ekyo.pl/en/


$themedir = "blossom";
$themename = "Blossom";
$module_space[0] = "main";
$module_space[1] = "footer";
?>