<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php theme_meta(); ?>
</head>

<body>

<div id="contenedor">
 <div id="contenedorArriba"></div>
 <div id="contenedorCuerpo">
 <div id="cuadro"> <span id="logo"><?php theme_sitetitle(); ?></span>
 </div>
 </div>
 <div id="cuerpo">
 <div id="izquierdo">
 <div id="menu">
 <?php theme_menu('<li><a href="#file">#title</a></li>','<li class="active"><a href="#file">#title</a></li>'); ?>
 </div>
 </div>
 <div id="derecho">
 <p><span class="titulo"><?php theme_pagetitle(); ?></span><br />
 <!--><img src="data/themes/Coffee/images/separador3.jpg" height="10" width="75" alt="" /> <br /><-->
 <span class="textoNormal">
 <?php theme_content(); ?>
 <?php theme_module("main"); ?>
 </span>
 </div>
 </div>
 <div id="contenedorAbajo"></div>
</div>
<div id="design">
 <?php theme_module("footer"); ?>
 <center><a href="login.php">admin</a> | <a href="http://www.pluck.ekyo.pl/en/" title="Pluck Power Pack by ekyo.pl">powered by</a> <a href="http://www.pluck-cms.org/">pluck</a> | Design based on 'Coffee' by <a href="http://www.t4p.me.uk/" target="_blank">T4P</a> | <a href="http://en.wikipedia.org/wiki/Akseli_Gallen-Kallela" target="_blank">header image</a></center> 
</div>		
</body>
</html>