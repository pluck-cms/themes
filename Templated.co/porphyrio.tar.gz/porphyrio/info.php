<?php

$themedir = 'porphyrio';
$themename = 'porphyrio';
$module_space[0] = 'main';
$module_space[1] = 'footer';
?>