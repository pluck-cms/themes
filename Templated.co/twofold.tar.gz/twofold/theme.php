<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : TwoFold 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130526

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php theme_sitetitle(); ?></title>
<?php theme_meta(true); ?>
<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,600,700" rel="stylesheet" />
<link href="data/themes/<? echo $page_theme; ?>/default.css" rel="stylesheet" type="text/css" media="all" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
<div id="header" class="container">
	<div id="logo">
		<h1><a href="#"><?php theme_sitetitle(); ?></a></h1>
	</div>
	<div id="menu">
		<?php theme_menu('ul', 'li', 'active', 1); ?>
	</div>
</div>
<div id="wrapper">
	<div id="welcome" class="wrapper-style1">
		<div class="title">
			<h2><?php theme_pagetitle(); ?></h2>
		</div>
	</div>
	<div id="page" class="container">
		<div id="content">
			<?php theme_content(); ?>
			<?php theme_area('main'); ?>
		</div>
		<div id="sidebar">
			<div id="sbox1">
				<div class="title">
					<h2>Submenu</h2>
				</div>
					<?php theme_menu('ul class=style2', 'li', 'active', 2); ?>
			</div>
		</div>
	</div>
</div>
<div id="featured-wrapper">
	<div id="featured" class="container">
		<div id="box1">
			<div>
				<h2>Nulla luctus eleifend</h2>
			</div>
			<ul class="style1">
				<li class="first"><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Mauris vel.veroeros nisl feugiat lorem</a></li>
				<li><a href="#">Sed in volutpat nisl mauris tempus. nulla</a></li>
				<li><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Blandit feugiat lorem diam nullam dolore</a></li>
			</ul>
		</div>
		<div id="box2">
			<div>
				<h2>Maecenas luctus lectus</h2>
			</div>
			<ul class="style1">
				<li class="first"><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Mauris vel.veroeros nisl feugiat lorem</a></li>
				<li><a href="#">Sed in volutpat nisl mauris tempus. nulla</a></li>
				<li><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Blandit feugiat lorem diam nullam dolore</a></li>
			</ul>
		</div>
		<div id="box3">
			<div>
				<h2>Etiam posuere augue</h2>
			</div>
			<ul class="style1">
				<li class="first"><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Mauris vel.veroeros nisl feugiat lorem</a></li>
				<li><a href="#">Sed in volutpat nisl mauris tempus. nulla</a></li>
				<li><a href="#">Dolore feugiat consequat et amet nullam</a></li>
				<li><a href="#">Blandit feugiat lorem diam nullam dolore</a></li>
			</ul>
		</div>
	</div>
</div>
<div id="footer" class="container">
	<div>
		<div>
			<h2>Get in touch</h2>
			<span class="byline">Phasellus nec erat sit amet nibh pellentesque congue</span> </div>
		<ul class="contact">
			<li><a href="#" class="icon icon-twitter"><span>Twitter</span></a></li>
			<li><a href="#" class="icon icon-facebook"><span></span></a></li>
			<li><a href="#" class="icon icon-dribbble"><span>Pinterest</span></a></li>
			<li><a href="#" class="icon icon-tumblr"><span>Google+</span></a></li>
			<li><a href="#" class="icon icon-rss"><span>Pinterest</span></a></li>
		</ul>
	</div>
	<p>&copy; Untitled. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
</body>
</html>
