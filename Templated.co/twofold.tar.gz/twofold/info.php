<?php

$themedir = 'twofold';
$themename = 'TwoFold';
$module_space[0] = 'main';
$module_space[1] = 'footer';
?>